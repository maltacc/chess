#include "move.h"
extern const int DIM = 8;
extern const Move RESIGN{Pos{0, 0}, Pos{DIM - 1, DIM - 1}, Type::K};
