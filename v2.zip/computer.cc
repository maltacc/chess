#include "computer.h"

Computer::Computer(LegalBoard *board): Player{board} {lb = *board;}
