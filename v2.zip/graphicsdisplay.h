#ifndef __GRAPHICSDISPLAY_H__
#define __GRAPHICSDISPLAY_H__
#include "observer.h"

class GraphicsDisplay: public Observer {
    
}; 

#endif 
