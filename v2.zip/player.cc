#include "player.h"
using namespace std; 

Player::Player() {} 

Player::Player(LegalBoard *b): b{b} {}

Player::~Player() {}
